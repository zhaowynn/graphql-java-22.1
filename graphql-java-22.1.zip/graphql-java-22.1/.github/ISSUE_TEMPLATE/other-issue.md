---
name: Other issue
about: Generic issue
title: ''
labels: ''
assignees: ''

---

If you have a general question or seeking advice how to use something please create a new topic in our GitHub discussions forum: https://github.com/graphql-java/graphql-java/discussions. Thanks.
