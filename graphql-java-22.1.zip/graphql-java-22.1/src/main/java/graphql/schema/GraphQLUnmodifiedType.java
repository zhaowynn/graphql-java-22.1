package graphql.schema;


import graphql.PublicApi;

@PublicApi
public interface GraphQLUnmodifiedType extends GraphQLNamedType {
}
