package graphql.schema;


import graphql.PublicApi;

@PublicApi
public interface GraphQLCompositeType extends GraphQLNamedOutputType {
}
