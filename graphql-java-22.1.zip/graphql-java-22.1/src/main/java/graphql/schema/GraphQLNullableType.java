package graphql.schema;


import graphql.PublicApi;

@PublicApi
public interface GraphQLNullableType extends GraphQLType {
}
