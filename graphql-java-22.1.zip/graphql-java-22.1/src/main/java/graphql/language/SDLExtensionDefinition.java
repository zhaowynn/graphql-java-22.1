package graphql.language;


import graphql.PublicApi;

/**
 * A marker interface for Schema Definition Language (SDL) extension definitions.
 */
@PublicApi
public interface SDLExtensionDefinition {

}
