package graphql.language;


import graphql.PublicApi;

@PublicApi
public interface Definition<T extends Definition> extends Node<T> {

}
