package graphql.language;


import graphql.PublicApi;

@PublicApi
public interface Type<T extends Type> extends Node<T> {

}
