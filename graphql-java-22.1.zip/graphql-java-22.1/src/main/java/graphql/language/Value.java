package graphql.language;


import graphql.PublicApi;

@PublicApi
public interface Value<T extends Value> extends Node<T> {

}
