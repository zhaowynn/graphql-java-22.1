package graphql.language;

import graphql.PublicApi;

@PublicApi
public interface ScalarValue<T extends Value> extends Value<T> {
}
